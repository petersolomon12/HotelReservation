//Peter Ogungbamigbe

package termproject;



import javax.swing.*;
import java.awt.*;

public class PrintReceipt extends JFrame 

{

	
	public PrintReceipt(String sRoom, String sRoomType, String sBedType, Integer iAdult, Integer iChildren, Integer iInfant, String sBookingDate, 
			String sName, String sEmail , String sDOB , String sAddress, String sPhone , String sCCName,String sCCType, String sCCNumber, String sCCExpiry, String sCCCV)
	
	{
		Container c=getContentPane();
		c.setLayout(new BorderLayout());
		
		JPanel Panel2 = new JPanel(null);
		 JScrollPane jsp = new JScrollPane(Panel2);
			Panel2.setPreferredSize(new Dimension(500,400));
	        Panel2.setLayout(null);

		
		
		JLabel LTitle = new JLabel("Hotel Receipt");
		JLabel LRoom = new JLabel("Room : "+ sRoom);
		JLabel LRoomType = new JLabel("Type Room : "+sRoomType);
		JLabel LBedType = new JLabel("Type Bed : " +sBedType );
		JLabel LNameTitle = new JLabel("Customer Information ");
		JLabel LName = new JLabel("Name : " + sName  );
		JLabel LBookingDate = new JLabel("Date Booked : "+ sBookingDate );
		JLabel LAddress = new JLabel("Billing Address : "+ sAddress );
		JLabel LPhone = new JLabel("Phone Number : " + sPhone );
		JLabel LDOB = new JLabel("Date Of Birth : " + sDOB );
		JLabel LEmail = new JLabel("Email : " + sEmail );
		JLabel LCCTitle = new JLabel("Information On Credit Card Used ");
		JLabel LCCName = new JLabel("Credit Card Name : "+ sCCName );
		JLabel LCCExpiry = new JLabel("Card Expiry : "+ sCCExpiry);
		JLabel LCCType = new JLabel("Card Type : "+ sCCType );
		JLabel LNoPeople = new JLabel("Number Of People ");
		JLabel LAdult = new JLabel("No Of Adult : "+iAdult );
		JLabel LChildren = new JLabel("No of Children : "+ iChildren );
		JLabel LInfant = new JLabel("No Of Infants : "+iInfant );


		

	


		LTitle.setBounds(170,15,500,45);
		LRoom.setBounds(20,80,300,20);
		LRoomType.setBounds(20,125,300,20);
		LBedType.setBounds(20,170,300,20);
		LBookingDate.setBounds(20,215,300,20);
		
		
		LNameTitle.setBounds(200,250,500,45);
		LName.setBounds(20,315,300,20);
		LEmail.setBounds(20,360,300,20);
		LDOB.setBounds(20,405,300,20);
		LAddress.setBounds(20,450,300,20);
		LPhone.setBounds(20,495,300,20);
		
		LCCTitle.setBounds(200,530,500,45);		
		LCCName.setBounds(20,595,300,20);
		LCCType.setBounds(20,640,300,20);
		LCCExpiry.setBounds(20,685,300,20);


		
		
		LNoPeople.setBounds(1050,15,500,45);	
		LAdult.setBounds(900,80,300,20);
		LChildren.setBounds(900,125,300,20);
		LInfant.setBounds(900,170,300,20);
	



		Panel2.add(LNoPeople);
		Panel2.add(LTitle);
		Panel2.add(LRoom);
		Panel2.add(LRoomType);
		Panel2.add(LBedType);
		Panel2.add(LBookingDate);
		Panel2.add(LName);
		Panel2.add(LAdult);
		Panel2.add(LChildren);
		Panel2.add(LInfant);
		Panel2.add(LAddress);
		Panel2.add(LPhone);
		Panel2.add(LDOB);
		Panel2.add(LEmail);
		Panel2.add(LCCName);
		Panel2.add(LCCExpiry);
		Panel2.add(LCCType);		
		Panel2.add(LNameTitle);
		Panel2.add(LCCTitle);



		Panel2.setBackground(Color.white);

		c.add(Panel2, BorderLayout.CENTER);


		setSize(700,650);
		setVisible(true);

	}
}