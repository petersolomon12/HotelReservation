//Peter Ogungbamigbe

package termproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Login extends JFrame
{
	
	Container c = getContentPane();
	JPanel HotelLogin = new JPanel(null);
	JPanel Image = new JPanel(null);
	JLabel jl = new JLabel();

	
	public boolean bCheck=true;

	JLabel LUserName, LPassword;

	JLabel LMasterBed1 = new JLabel("Please get all your information and details to book this hotel!!!");

	JTextField TFUserName;
	JPasswordField TPPassword;

	JButton BLogin;
	
	
	

	public Login()
	{
		WindowUtil.setNativeLookAndFeel();
		setPreferredSize(new Dimension(796,572));


		
		

		jl.setIcon(new ImageIcon("C:\\Users\\lizzy\\Downloads\\Peter's Hotel.jpg"));

		
		jl.setBounds(0, 340, 790, 200);


		HotelLogin.setBounds(500,0,350, 340);


		LUserName = new JLabel("         User Name ");
		LPassword = new JLabel("         Password ");
		TFUserName = new JTextField(10);
		TPPassword = new JPasswordField(10);
		BLogin = new JButton("Sign In");

		LUserName.setBounds(40, 100, 100, 21);
		LPassword.setBounds(40, 140, 100, 21);
		TFUserName.setBounds(160, 100, 100, 21);
		TPPassword.setBounds(160, 140, 100, 21);
		BLogin.setBounds(160, 200, 100,25);
		jl.setBounds(0, 0, 500, 350);


		LMasterBed1.setBounds(10, 60, 500, 20);

		HotelLogin.add(LUserName);
		HotelLogin.add(TFUserName);
		HotelLogin.add(LPassword);
		HotelLogin.add(TPPassword);
		HotelLogin.add(BLogin);
		Image.add(jl);

	

		

		c.add(HotelLogin);
		c.add(Image);


		pack();
		setVisible(true);

		addWindowListener(new ExitListener());

		LMasterBed1.addMouseListener(new mouse3(this, true));

		BLogin.addActionListener(new button1(this));
	}

	public static void main(String args[])
	{
		new Login();
	}
}



class button1 implements ActionListener
{
	Login type;
	char[] cCheck, cPassword={'a','d','m','i','n','\0'};
	JFrame f;
	String sCheck,sCheck1="admin";

	public button1(Login type)
	{
		this.type = type;
	}
	public void actionPerformed(ActionEvent e)
	{
		cCheck=type.TPPassword.getPassword();
		sCheck = type.TFUserName.getText();
		if ((sCheck1.equals(sCheck)) && check())
		{
			type.HotelLogin.add(type.LMasterBed1);

			type.HotelLogin.remove(type.LUserName);
			type.HotelLogin.remove(type.TFUserName);
			type.HotelLogin.remove(type.LPassword);
			type.HotelLogin.remove(type.TPPassword);
			type.HotelLogin.remove(type.BLogin);

			type.c.repaint();
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Invalid username or password. Try again");
		}
	}
	public boolean check()
	{
		if (cCheck.length >= 6 || cCheck.length < 4)
			return false;
		for(int i=0;i<=4;i++)
		{
			if(cCheck[i]!=cPassword[i])
				return false;
		}
		return true;
		
	}
}

class mouse1 extends MouseAdapter
{
	Login type;
	boolean bCheck;

	public mouse1(Login type, boolean bCheck)
	{
		this.type = type;
		this.bCheck = bCheck;
	}
	
	public void mouseClicked(MouseEvent e)
	{
		if(bCheck)
			type.bCheck = true;
		else
			type.bCheck = false;
		

	}
}



class mouse3 extends MouseAdapter
{
	Login type;
	boolean bCheck;

	public mouse3(Login type, boolean bCheck)
	{
		this.type = type;
		this.bCheck = bCheck;
	}
	public void mouseEntered(MouseEvent e)
	{
		type.LMasterBed1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}
	public void mouseClicked(MouseEvent e)
	{
		if (bCheck)
			new MasterBed(type);
		
	}
}


class mouse2 extends MouseAdapter
{
	Login type;
	boolean bCheck;

	public mouse2(Login type, boolean bCheck)
	{
		this.type = type;
		this.bCheck = bCheck;
	}
	
	
	}
