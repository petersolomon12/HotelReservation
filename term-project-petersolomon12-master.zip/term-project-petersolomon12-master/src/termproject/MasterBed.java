//Peter Ogungbamigbe

package termproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;



public class MasterBed extends JFrame
{
	JComboBox ComboBoxRoom, ComboBoxTypeRoom, ComboBoxTypeBed, ComboBoxAdult, ComboBoxChildren, ComboBoxInfant, ComboBoxCardType;
	JLabel LabelRoom, LabelTypeRoom, LabelDateBooking, LabelTypeBed, LabelAdult,
	LabelChild, LabelBaby, LabelBookingDetails, LabelGuestDetails, 
	LabelDate, LabelDate1, LabelguestName, LabelguestPhone,LabelguestEmail,LabelguestAddress,LabelguestDOB,
	LabelCName, LabelCNumber, LabelCExpiry, LabelCCV,
	LabelCardType, LabelCardDetails;
	JTextField TextFieldBookingDate, TextFieldCName, TextFieldCNumber, TextFieldCExpiry,
	TextFieldCCV, TextFieldguestName, TextFieldguestPhone, TextFieldguestEmail,
	TextFieldguestAddress, TextFieldguestDOB;
	JCheckBox CheckBoxVisa, CheckBoxMasterCard, CheckBoxAmericanExpress;
	JButton ButtonFindBooking;
	JPanel PPanel1, PPanel2;
	

	

	Login type1;

	public MasterBed(Login type1)
	{
		Container c =getContentPane();
		c.setLayout(new BorderLayout());
		String[] sItem1={"Master"};
		String[] sItem2 ={ "En-Suite", "Junior Suite ", "Studio" };
		String[] sItem3={"Single","Double", "Triple", "Queen", "King", "Studio"};
		String[] sItem4={"Visa","Mastercard", "American Express"};

		
		this.type1 = type1;
		PPanel1 = new JPanel(null);
		PPanel1.setPreferredSize(new Dimension(1000,500));

		
		
		
		LabelBookingDetails = new JLabel("Booking Details");
		LabelCardDetails = new JLabel("Card Details");

		LabelRoom = new JLabel("Room:          ");
		LabelTypeRoom = new JLabel("Type of Room:         ");
		LabelTypeBed = new JLabel("Bed:         ");
		
		LabelDateBooking = new JLabel("Booking Date:");
		
		LabelguestName = new JLabel("Guest Name: ");
		TextFieldguestName = new JTextField(" ",15);
		
		LabelguestPhone = new JLabel("Guest Phone: ");
		TextFieldguestPhone = new JTextField(" ",10);
		
		
		LabelguestEmail = new JLabel("Guest Email: ");
		TextFieldguestEmail = new JTextField(" ",15);
		
		
		LabelguestAddress = new JLabel("Guest Address: ");
		TextFieldguestAddress = new JTextField(" ", 20);



		LabelguestDOB = new JLabel("Guest Date Of Birth: ");
		TextFieldguestDOB = new JTextField(5);
		
		
		LabelCName = new JLabel("Name: ");
		TextFieldCName = new JTextField("", 15);
		
		LabelCardType = new JLabel("Type: ");
		
		
		
		LabelCNumber = new JLabel("Number: ");
		TextFieldCNumber = new JTextField("", 10);
		
		LabelCExpiry = new JLabel("Exp Date: ");
		TextFieldCExpiry = new JTextField("", 5);
		
		LabelCCV = new JLabel("CVV: ");
		 TextFieldCCV = new JTextField("", 5); 
			
		
		

		
		
		ComboBoxRoom = new JComboBox(sItem1);
		ComboBoxTypeRoom = new JComboBox(sItem2);
		ComboBoxTypeBed = new JComboBox(sItem3);
		ComboBoxCardType = new JComboBox(sItem4);

		TextFieldBookingDate = new JTextField(10);
		LabelDate = new JLabel("(DD/MM/YYYY)");
		LabelDate1 = new JLabel("(DD/MM/YYYY)");

		
		ButtonFindBooking = new JButton("Find Booking");

		LabelBookingDetails.setBounds(20,3,100,20);
		LabelCardDetails.setBounds(20,420,100,20);

		
		LabelRoom.setBounds(20,40,100,20);
		ComboBoxRoom.setBounds(120,40,100,20);

		LabelTypeRoom.setBounds(20,100,100,20);
		ComboBoxTypeRoom.setBounds(120,100,100,20);
		
		LabelTypeBed.setBounds(20,160,100,20);
		ComboBoxTypeBed.setBounds(120,160,100,20);

		LabelDateBooking.setBounds(20,220,100,20);
		TextFieldBookingDate.setBounds(120,220,100,20);
		LabelDate.setBounds(230,220,100,20);

		LabelguestName.setBounds(20,220,180,100);
		TextFieldguestName.setBounds(20,280,180,20);
		
		LabelguestEmail.setBounds(220,220,180,100);
		TextFieldguestEmail.setBounds(220,280,180,20);


		LabelguestDOB.setBounds(420,220,180,100);
		TextFieldguestDOB.setBounds(420,280,180,20);
		
		LabelDate1.setBounds(610,280,180,20);


		LabelguestAddress.setBounds(20,300,180,100);
		TextFieldguestAddress.setBounds(20,360,180,20);



		LabelguestPhone.setBounds(220,300,180,100);
		TextFieldguestPhone.setBounds(220,360,180,20);
		
		ButtonFindBooking.setBounds(300,600,150,60);
		
		LabelCName.setBounds(20,440,100,20);
		TextFieldCName.setBounds(80,440,180,20);
		
		LabelCardType.setBounds(280,440,100,20);
		ComboBoxCardType.setBounds(320,440,100,20);
	
		
		LabelCNumber.setBounds(20,500,150,20);
		TextFieldCNumber.setBounds(80,500,180,20);
		
		LabelCExpiry.setBounds(280,500,150,20);
		TextFieldCExpiry.setBounds(340,500,60,20);
		
		LabelCCV.setBounds(420,500,150,20);
		TextFieldCCV.setBounds(450,500,40,20);


		


		PPanel1.add(LabelBookingDetails);
		PPanel1.add(LabelCardDetails);		
		PPanel1.add(LabelRoom);
		PPanel1.add(ComboBoxRoom);
		PPanel1.add(LabelTypeRoom);
		PPanel1.add(ComboBoxTypeRoom);
		PPanel1.add(LabelDateBooking);
		PPanel1.add(TextFieldBookingDate);
		PPanel1.add(LabelDate);
		PPanel1.add(LabelDate1);
		PPanel1.add(LabelTypeBed);
		PPanel1.add(ComboBoxTypeBed);
		PPanel1.add(ButtonFindBooking);
		PPanel1.add(LabelguestEmail);
		PPanel1.add(LabelguestAddress);
		PPanel1.add(LabelguestDOB);
		PPanel1.add(LabelguestName);
		PPanel1.add(LabelguestPhone);
		PPanel1.add(TextFieldguestAddress);
		PPanel1.add(TextFieldguestDOB);
		PPanel1.add(TextFieldguestEmail);
		PPanel1.add(TextFieldguestName);
		PPanel1.add(TextFieldguestPhone);
		PPanel1.add(LabelCName);
		PPanel1.add(LabelCardType);
		PPanel1.add(LabelCNumber);
		PPanel1.add(LabelCExpiry);
		PPanel1.add(LabelCCV);
		PPanel1.add(TextFieldCName);
		PPanel1.add(TextFieldCNumber);
		PPanel1.add(TextFieldCExpiry);
		PPanel1.add(TextFieldCCV);
		PPanel1.add(ComboBoxCardType);
		
		

		PPanel1.setBackground(Color.white);

		c.add(PPanel1,BorderLayout.WEST);

		
		
		
		PPanel2 = new JPanel(null);
		PPanel2.setPreferredSize(new Dimension(500,160));

		LabelGuestDetails=new JLabel("NO. of Guests");

		LabelAdult = new JLabel("Adults(18+)");

		LabelChild = new JLabel("Children(5-17)");
		LabelBaby = new JLabel("Infants(under 5)");

		String[] item4={"1","2","3","4","5","6"};
		ComboBoxAdult = new JComboBox(item4);

		String[] item5={"0","1","2","3","4"};
		ComboBoxChildren = new JComboBox(item5);

		String[] item6={"0","1","2","3"};
		ComboBoxInfant = new JComboBox(item6);

		LabelGuestDetails.setBounds(40,3,100,20);

		LabelAdult.setBounds(40,40,100,20);
		ComboBoxAdult.setBounds(140,40,100,20);

		LabelChild.setBounds(40,105,100,20);
		ComboBoxChildren.setBounds(140,105,100,20);

		LabelBaby.setBounds(40,170,100,20);
		ComboBoxInfant.setBounds(140,170,100,20);



		PPanel2.add(LabelGuestDetails);
		PPanel2.add(LabelAdult);
		PPanel2.add(LabelChild);
		PPanel2.add(LabelBaby);
		PPanel2.add(ComboBoxAdult);
		PPanel2.add(ComboBoxChildren);
		PPanel2.add(ComboBoxInfant);


		PPanel2.setBackground(Color.white);

		c.add(PPanel2,BorderLayout.EAST);

		setSize(795,580);
		setVisible(true);

		ButtonFindBooking.addActionListener(new button3(this, type1));
	}
	public static void main(String args[])
	{
		Login type1=null;
		new MasterBed(type1);
	}
}

class button3 implements ActionListener
{
	MasterBed type;
	Login type1;
	button3(MasterBed type, Login type1)
	{
		this.type = type;
		this.type1 = type1;
	}
	
	
	public void actionPerformed(ActionEvent e)
	{
		String sRoom = (String)type.ComboBoxRoom.getSelectedItem();
		String sRoomType = (String)type.ComboBoxTypeRoom.getSelectedItem();
		String sBedType = (String)type.ComboBoxTypeBed.getSelectedItem();
		String sBookingDate = type.TextFieldBookingDate.getText();
		String sName = type.TextFieldguestName.getText();
		String sEmail = type.TextFieldguestEmail.getText();
		String sDOB = type.TextFieldguestDOB.getText();
		String sAddress = type.TextFieldguestAddress.getText();
		String sPhone = type.TextFieldguestPhone.getText();
		String sCCName = type.TextFieldCName.getText();
		String sCCType = (String)type.ComboBoxCardType.getSelectedItem();
		String sCCNumber = type.TextFieldCNumber.getText();
		String sCCExpiry = type.TextFieldCExpiry.getText();
		String sCCCVV = type.TextFieldCCV.getText();


		


		Integer iAdult = Integer.parseInt((String)type.ComboBoxAdult.getSelectedItem());
		Integer iChildren = Integer.parseInt((String)type.ComboBoxChildren.getSelectedItem());
		Integer iInfant = Integer.parseInt((String)type.ComboBoxInfant.getSelectedItem());

		int i = 0;

	
		

		int iCount=0;
		int iSeatCount=0;

		
		String[] sTempRoom=new String[1250];
		String[] sTempRoomType=new String[1250];
		String[] sTempBedType=new String[1250];
		String[] sTempBookingDate=new String[1250];
		String[] sTempName=new String[1250];
		String[] sTempEmail=new String[1250];
		String[] sTempDOB=new String[1250];
		String[] sTempAddress=new String[1250];
		String[] sTempPhone=new String[1250];
		String[] sTempCCName=new String[1250];
		String[] sTempCCType=new String[1250];
		String[] sTempCCNumber=new String[1250];
		String[] sTempCCExpiry=new String[1250];
		String[] sTempCCCVV=new String[1250];
		Integer[] iTempAdult=new Integer[1250];
		Integer[] iTempChildren=new Integer[1250];
		Integer[] iTempInfant=new Integer[1250];

		try
		{
			Save2 save1;
			ObjectInputStream OIS1 = new ObjectInputStream(new FileInputStream("save2"));
			do
			{
				save1 = (Save2)OIS1.readObject();
				sTempRoom[iCount] = save1.sRoom;
				sTempRoomType[iCount] = save1.sRoomType;
				sTempBedType[iCount] = save1.sBedType;
				sTempBookingDate[iCount] = save1.sBookingDate;
				sTempName[iCount] = save1.sName;
				sTempEmail[iCount] = save1.sEmail;
				sTempDOB[iCount] = save1.sDOB;
				sTempAddress[iCount] = save1.sAddress;
				sTempPhone[iCount] = save1.sPhone;
				sTempCCName[iCount] = save1.sCCName;
				sTempCCType[iCount] = save1.sCCType;
				sTempCCNumber[iCount] = save1.sCCNumber;
				sTempCCExpiry[iCount] = save1.sCCExpiry;
				sTempCCCVV[iCount] = save1.sCCCVV;
				iTempAdult[iCount] = save1.iAdult;
				iTempChildren[iCount] = save1.iChildren;
				iTempInfant[iCount] = save1.iInfant;

				iCount++;
				if(save1.sBookingDate.equals(sBookingDate))
					if(save1.sRoomType.equals(sRoomType))
						iSeatCount=iSeatCount + save1.iAdult + save1.iChildren + save1.iInfant;
			}while(save1!=null);
			OIS1.close();

		}
		catch(Exception e1)
		{
			
		} 

		iSeatCount = iSeatCount + iAdult + iChildren + iInfant;

		if(iSeatCount > 30)
		{
			JOptionPane.showMessageDialog(null,"Rooms are fully booked Sorry!");
		}
		else
		{
			int iChoice = JOptionPane.showConfirmDialog(null,"Rooms are available. Do you want to Book now?");
			if(iChoice == JOptionPane.YES_OPTION)
			{
				new PrintReceipt(sRoom, sRoomType, sBedType, iAdult, iChildren, iInfant, sBookingDate,
						sName, sEmail, sDOB, sAddress, sPhone, sCCName, sCCType,
						sCCNumber, sCCExpiry, sCCCVV);
			try
			{
				Save2 save2=new Save2(sRoom, sRoomType, sBedType, iAdult, iChildren, iInfant, sBookingDate,
						sName, sEmail, sDOB, sAddress,  sPhone, sCCName,
						sCCType, sCCNumber, sCCExpiry, sCCCVV);
				ObjectOutputStream OOS1 = new ObjectOutputStream(new FileOutputStream("save2"));
				for(i=0;i<iCount;i++)
				{
					Save2 temp1=new Save2(sTempRoom[i], sTempRoomType[i], sTempBedType[i], iTempAdult[i], iTempChildren[i], iTempInfant[i], sTempBookingDate[i], 
							sTempName[i] , sTempEmail[i], sTempDOB[i], sTempAddress[i],  sTempPhone[i],
							sTempCCName[i], sTempCCType[i], sTempCCNumber[i], sTempCCExpiry[i], sTempCCCVV[i]);
					OOS1.writeObject(temp1);
System.out.println(temp1);
				}
				OOS1.writeObject(save2);
				OOS1.close();
			}catch(Exception e1)
			{
				System.out.println(e1);
			}
			}
			else
			{
			}
		}
	}
}



class Save2 implements Serializable
{
	String sRoom, sRoomType, sBedType, sBookingDate,
	sAddress, sPhone, sDOB, sEmail,  sCCNumber, sName, sCCName, 
	sCCExpiry, sCCCVV, sCCType;
	Integer  iAdult, iChildren, iInfant;
	public Save2(String sRoom, String sRoomType, String sBedType, Integer iAdult, Integer iChildren, Integer iInfant, String sBookingDate, 
			String sAddress, String sPhone , String sDOB , String sEmail, String sName ,
			String sCCName, String sCCNumber, String sCCExpiry, String sCCCVV, String sCCType)
	{
		this.sRoom=sRoom;
		this.sRoomType=sRoomType;
		this.sBedType=sBedType;
		this.iAdult=iAdult;
		this.iChildren=iChildren;
		this.iInfant=iInfant;
		this.sBookingDate=sBookingDate;
		this.sName=sName;
		this.sEmail=sEmail;
		this.sDOB=sDOB;
		this.sAddress=sAddress;
		this.sPhone=sPhone;
		this.sCCName=sCCName;
		this.sCCType=sCCType;
		this.sCCNumber=sCCNumber;
		this.sCCExpiry=sCCExpiry;
		this.sCCCVV=sCCCVV;

		
		
	}
	public String toString()
	{
		return sRoom+" "+sRoomType+" "+sBedType+" "+sBookingDate + " " +
	sAddress+ " " +sPhone + " " +sDOB + " " +sEmail+ " "+sName +" " +
	sCCName + " " +sCCNumber + " " + sCCExpiry + " " + sCCCVV+ " " + sCCType + " " +
	iAdult+" "+iChildren+" "+iInfant+" ";
	}
	
}